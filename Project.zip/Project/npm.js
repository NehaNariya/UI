//# angular install karva mate => npm install -g @angular/cli => terminal ma karvu
//# angular ma new project banava mate => ng new Project_name
//# angular ma component banava mate => ng g c component_name
//# angular ma service banava mate => ng g s service/service_name
//# anguular nu version check karva mate => angular --version
//# angular ne run karva mate => ng serve -o

//# node nu version check karva mate => node --version
//# npm i
//# npm install -g nodeman 
//# npm i express mongoose body-parser
//# npm i express
//# npm i body-parser
//# npm i mongoose
//# run karva mate => node index


///////////////////////////

// var http = require('http')
// var server =  http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// })
// server.listen(3000);

//or 1 & 2 mathi game te chale

// var http = require('http')
// http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// }).listen(3000);



// var http = require('http')
// http.createServer(function(req,res){
//     res.write("Hello World");
//     res.end();
// }).listen(3000,()=>{
//     console.log("Server Started");
// });

//-------------------------------output:node main-----------


///////////////////////

/////expressjs
// var express = require('express');
// var app = express();

// app.get("/",(req,res)=>{
//     res.sendFile(__dirname+"/index.html");
// });

// app.listen(3000,() => {
//     console.log("server started");
// });



///////////////////////////////////////////////////

/////request & responce
//install/npm install -g nodeman 

var http = require('http');

http.createServer((req,res)=>{
    if(req.url=="/"){
        res.write("This is a Students Page");
    }
    else if(req.url == "/admin"){
        res.write("This is an admin Page");
    }
    res.end();
}).listen(3000,()=>{
    console.log("Server Started");
})



//----------------------output:nodeman main----node main-------



/////////////////////



///event Demo

var event = require('events');

var em = new event.EventEmitter();

em.on("myEvent",(data)=>{
    console.log(data);
})

em.emit('myEvent',"This is my data");



//////////////////////


//////event demo age

var event = require('events');

var em = new event.EventEmitter();
var ch = new event.EventEmitter();

em.on("myEvent",(data)=>{
    console.log(data);
})

ch.on("checkage", (age) => {
    if(age >= 18) {
        console.log("Eigble");
    }
    else
    {
        console.log("Not Eligble");
    }
})

em.emit('myEvent',"This is my data");

ch.emit('checkage',10)

//output:node eventDemoage lakhvu



///////////////////////


//Connectivity

//# npm i mongoose express body-parser
//# npm i mongoose
//# npm i express
//# npm i body-parser

var mongoose = require('mongoose');
var express = require('express');
var bodyParser =  require('body-parser');

mongoose.connect("mongodb+srv://neha:neha882000@cluster0.xtwk6fo.mongodb.net/?retryWrites=true&w=majority").then(() => {
    console.log("DB Connected");

    app = express();
    app.listen(3000,()=>{
        console.log("Server started at 3000");
    })
}).catch((err)=>{
    console.log(err);
})

//output:
//DB Connected
//Server started at 3000


//////////////////////////////////


//API-get data

///index.js

var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var route = require('./route');

mongoose.connect("mongodb+srv://neha:Neha08082000@cluster0.xtwk6fo.mongodb.net/student?retryWrites=true&w=majority").then(()=>{
console.log("conncted");
app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({extended:false}))
app.use('/api',route)

app.listen(3000,()=>{
    console.log("Server Running")
})
}).catch((err)=>{
    console.log(err);
})

//model folder  ni andar movies.js name file bannavi

//movie.js

var mongoose = require('mongoose');

var studSchema = mongoose.Schema({
    name:String,
    city:String,
    pin:String,
    branch:String
})

module.exports = mongoose.model("studs",studSchema);


//route.js

var express = require('express');
const movie = require('./Model/movie');
var stud = require('./Model/movie')
var route = express.Router();


route.get('/stud',async(req,res)=>{
  var imovie = await stud.find();
  res.send(imovie);

})
module.exports = route;

//////////////////////////////////


///API-post data

//index.js

var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var route = require('./route');

mongoose.connect("mongodb+srv://neha:Neha08082000@cluster0.xtwk6fo.mongodb.net/student?retryWrites=true&w=majority").then(()=>{
console.log("conncted");
app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({extended:false}))
app.use('/api',route)

app.listen(3000,()=>{
    console.log("Server Running")
})
}).catch((err)=>{
    console.log(err);
})


//////////////////////////////////////////

//MODEL folder ni andar movie.js ni file banavi

//movie.js

var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var route = require('./route');

mongoose.connect("mongodb+srv://neha:Neha08082000@cluster0.xtwk6fo.mongodb.net/student?retryWrites=true&w=majority").then(()=>{
console.log("conncted");
app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({extended:false}))
app.use('/api',route)

app.listen(3000,()=>{
    console.log("Server Running")
})
}).catch((err)=>{
    console.log(err);
})


///////////////////////////////////////////////
//route.js

var express = require('express');
var movie = require('./model/movie')
var route = express.Router();


route.get('/movie',async(req,res)=>{
  var imovie = await movie.find();
  res.send(imovie);

})
route.post("/movie",async(req,res)=>{
  const imovie = new movie({
    name:req.body.name,
    rating:req.body.rating
  })
  console.log(imovie)
  await imovie.save((err,msg)=>{
    if(err){
      res.status(500).json({
          "error":err
      })
  }
  else{
      res.status(200).json({
          "My-message":msg
      })
  }
  })
})
module.exports = route;

///////////////////////////////////////////

///////////

APIGetPost

//#index.js

var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var route = require('./route');

mongoose.connect("mongodb+srv://neha:Neha08082000@cluster0.xtwk6fo.mongodb.net/student?retryWrites=true&w=majority").then(()=>{
console.log("conncted");
app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({extended:false}))
app.use('/api',route)

app.listen(3000,()=>{
    console.log("Server Running")
})
}).catch((err)=>{
    console.log(err);
})

////

///model folder ni andar movie.js ni file banavi
//#movie.js

var mongoose = require('mongoose');

var movieSch = mongoose.Schema({
    name:String,
    city:String,
    pin:String,
    branch:String
})

module.exports = mongoose.model("moves",movieSch);


/////


///#route.js

var express = require('express');
const movie = require('./Model/movie');
var stud = require('./Model/movie')
var route = express.Router();

//fetching data


route.get('/movie',async(req,res)=>{
  var imovie = await movie.find();
  res.send(imovie);

})

//for posting data

route.post("/movies",async(req,res)=>{
  const imovie = new movie({
    name:req.body.name,
    rating:req.body.rating
  })
  console.log(imovie)
  await imovie.save((err,msg)=>{
    if(err){
      res.send(err);
    }
    else{
      res.send(msg);
    }
  });
})
module.exports = route;