var express = require('express');
const movie = require('./Model/movie');
var stud = require('./Model/movie')
var route = express.Router();

//fetching data

route.get('/movies',async(req,res)=>{
  var imovie = await stud.find();
  res.send(imovie);

})

//for posting data

route.post("/movie",async(req,res)=>{
  const imovie = new movie({
    name:req.body.name,
    rating:req.body.rating
  })
  console.log(imovie)
  await imovie.save((err,msg)=>{
    if(err){
      res.send(err);
    }
    else{
      res.send(msg);
    }
  });
})
module.exports = route;