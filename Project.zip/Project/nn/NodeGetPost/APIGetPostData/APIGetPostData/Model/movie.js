var mongoose = require('mongoose');

var movieSch = mongoose.Schema({
    name:String,
    city:String,
    pin:String,
    branch:String
})

module.exports = mongoose.model("moves",movieSch);