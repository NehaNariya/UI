var person = {
    name:'abc',dept:'MCA'
}

var sum = (a,b)=>{
    return a+b
}

var test = "testing"

module.exports = person;
module.exports = {test,sum};


//write a node script to create two function first for checking odd even, second for positive negative, export both and use in another file


// var oddeven = (val){
//     if(val%2==0)
//     {
//         return "positive"
//     }else{
//         return "negative"
//     }
// }