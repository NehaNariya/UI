var myfile = require('./test')
// console.log(test.name)
console.log(myfile.sum(10,20))
console.log(myfile.test)