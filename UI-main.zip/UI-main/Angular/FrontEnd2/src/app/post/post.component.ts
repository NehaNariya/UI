import { Component, OnInit } from '@angular/core';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  posts:any=[]
  key='id';

  Structure=[
{
 "userId": 1,
 "id": 1,
 "title": "This is title",
 "body": "This is body"
}]

  constructor(private _PostService:PostService) { }

  ngOnInit(): void {
    this._PostService.getPost().subscribe((data:any)=>{this.posts=data})
  }

}
