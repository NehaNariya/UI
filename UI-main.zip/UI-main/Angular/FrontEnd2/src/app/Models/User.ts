export interface iUser{
    email:string,
    pswd:string,
    cat:string
}

