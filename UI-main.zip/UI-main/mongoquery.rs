//m thi name chalu thatu hoy to
db.stud.find({name:{$regex:/^m/}})

//chhele m aavtu hoy to
db.stud.find({name:{$regex:/m$/}})

//vachhe game tya lin aavtu hoy to
db.stud.find({name:{$regex:/lin/}})

//line m thi start thati hoy to
db.stud.find({name:{$regex:/m/,$option:"si"}})

//json data puchay to tene import karva mate
mongoimport --db databasename --collection res --file D:\restaurants.json

//sort
db.mycol.find({},{"title":1,_id:0}).sort({"title":-1}) 

//Aggregation

db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$sum : 1}}}]) 
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$avg : "$session"}}}])
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$min : "$session"}}}])
db.tech.aggregate([{$group : {_id : "$name", total_sessions : {$max : "$session"}}}])



db.programmers.aggregate([{$group : {_id: "$type", TotalRecords: {$sum : 1}}}])
db.writers.aggregate([{$group:{_id:"$author",totalbook:{$sum:1}}}])


//node mate have

//aa code GETAPI mate no chhe
//model folder ni andar movies.js name ni file no code


var mongoose = require('mongoose');

var studSchema = mongoose.Schema({
    name:String,
    city:String,
    pin:String,
    branch:String
})

module.exports = mongoose.model("studs",studSchema);

//aa index.js file no code chhe

// var mongoose = require('mongoose');
// var express = require('express');
// var bodyParser = require('body-parser');
// var route = require('./route');

// mongoose.connect("mongodb+srv://devang:devang7492@cluster0.hchkg.mongodb.net/Student?retryWrites=true&w=majority").then(()=>{
// console.log("conncted");
// app = express();
// app.use(express.json());
// app.use(bodyParser.urlencoded({extended:false}))
// app.use('/api',route)

// app.listen(3004,()=>{
//     console.log("Server Running")
// })
// }).catch((err)=>{
//     console.log(err);
// })

//aa code rout.js mate no chhe

var express = require('express');
const movie = require('./model/movie');
var stud = require('./model/movie')
var route = express.Router();


route.get('/stud',async(req,res)=>{
  var imovie = await stud.find();
  res.send(imovie);

})
module.exports = route;


//aa code POSTAPI mate no chhe

//model folder ni andar movies.js name ni file no code

var mongoose = require('mongoose');

var studSchema = mongoose.Schema({
    name:String,
    rating:Number
})

module.exports = mongoose.model("movie",studSchema);

//index.js mate no

// var mongoose = require('mongoose');
// var express = require('express');
// var bodyParser = require('body-parser');
// var route = require('./route');

// mongoose.connect("mongodb+srv://devang:devang7492@cluster0.hchkg.mongodb.net/Student?retryWrites=true&w=majority").then(()=>{
// console.log("conncted");
// app = express();
// app.use(express.json());
// app.use(bodyParser.urlencoded({extended:false}))
// app.use('/api',route)

// app.listen(3004,()=>{
//     console.log("Server Running")
// })
// }).catch((err)=>{
//     console.log(err);
// })

//route.js mate no

var express = require('express');
var movie = require('./model/movie')
var route = express.Router();


route.get('/movie',async(req,res)=>{
  var imovie = await movie.find();
  res.send(imovie);

})
route.post("/movie",async(req,res)=>{
  const imovie = new movie({
    name:req.body.name,
    rating:req.body.rating
  })
  console.log(imovie)
  await imovie.save((err,msg)=>{
    if(err){
      res.status(500).json({
          "error":err
      })
  }
  else{
      res.status(200).json({
          "My-message":msg
      })
  }
  })
})
module.exports = route;